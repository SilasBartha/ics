package random;

public class Dice2 {
	public static void main(String[] args){
		//Results Array
		int[] results = {0,0,0,0,0,0}; 
		//Roll 600 dice
		for(int i = 0; i < 600; i++){
			int rand = (int)(Math.random()*6+1);
			//Count
			results[rand-1]++;
		}
		//Print results
		System.out.println("Results:");
		for(int i = 0; i < 6; i++){
			//1-6
			System.out.println("# of " + (i+1) + "s: " + results[i]);
		}
	}
}
