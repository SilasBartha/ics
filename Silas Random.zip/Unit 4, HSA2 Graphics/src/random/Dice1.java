package random;

public class Dice1 {
	public static void main(String[] args){
		int threes = 0;
		//Roll 20 dices, print results, print # of 3s rolled
		for(int i = 0; i < 20; i++){
			int rand = (int)(Math.random()*6+1);
			if(rand == 3) threes++;
			System.out.print(rand + " ");
		}
		System.out.print("\n# of 3s: " + threes);
	}
}
