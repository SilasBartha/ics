package random;

public class Random2 {

	public static void main(String[] args) {
		//20 random doubles up to 10
		for(int i = 0; i < 20; i++){
			System.out.println(Math.random()*10.0);
		}

	}

}
