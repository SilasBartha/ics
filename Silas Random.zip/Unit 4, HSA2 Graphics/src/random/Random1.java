package random;

public class Random1 {

	public static void main(String[] args) {
		//20 random ints from 0 to 200
		for(int i = 0; i < 20; i++){
			System.out.println((int)(Math.random()*200+1));
		}
	}

}
