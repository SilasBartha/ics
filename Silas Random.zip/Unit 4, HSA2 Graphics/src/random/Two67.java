package random;

public class Two67 {
	public static void main(String[] args){
		//Number of 67s, and number of trials
		int sixtySevens = 0;
		int trials = 0;
		//Keep generating numbers until 2 67s are returned
		while(sixtySevens<2){
			//Count trials
			trials++;
			//Increase number of 67s if random number is 67
			if((int)(Math.random()*100+1)==67){
				sixtySevens++;
			}
		}
		//Print results.
		System.out.println("Two 67s were returned after " +trials+ " trials.");
	}
}
