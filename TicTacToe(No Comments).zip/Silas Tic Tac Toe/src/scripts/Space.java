package scripts;

import java.awt.Rectangle;

public class Space extends Rectangle{
	private static final long serialVersionUID = 1L;
	int placeX = 0, placeY = 0;
	int occupied = 0;
	
	Space(){
	}

}
