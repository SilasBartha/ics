package scripts;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Point;
import java.awt.Toolkit;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import hsa2x.GraphicsConsole;

public class TicTacToe {
	int vs = 800;
	GraphicsConsole gc = new GraphicsConsole(vs,vs,"Tic Tac Toe");
	Color wood = new Color(205, 136, 102);
	Color carve = wood.darker().darker();
	Color highlight = new Color(0,255,0,100);
	Color shadow = new Color(0,0,0,100);
	Color bgColor = new Color(250,235,215);
	ArrayList<Space> spaces = new ArrayList<Space>();
	int boardSize = 600;
	int gridSize = 190;
	int winner = 0;
	int p1Wins = 0;
	int p2Wins = 0;
	Point m = new Point(0,0);
	boolean player1Turn = true;
	boolean gameOver = false;
	InputStream h1Stream = TicTacToe.class.getResourceAsStream("/fnt/BabelStoneModern.ttf");
	Font h1;
	Button resetButton = new Button(); 
	
	public static void main(String[] args) {
		new TicTacToe();
	}
	
	TicTacToe(){
		setup();
		while(true){
			draw();
			if(!gameOver){
				for(Space s: spaces){
					if(s.contains(m)&&gc.getMouseClick()>0&&!gc.isMouseMoved()){
						if(s.occupied ==0){
							AudioInputStream placeSound;
							Clip placeClip;
							try {
								placeSound = AudioSystem.getAudioInputStream(this.getClass().getResource("/snd/place.wav"));
								placeClip = AudioSystem.getClip();
								placeClip.open(placeSound);
								placeClip.start();
							} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
								e.printStackTrace();
							}
							if(player1Turn){
								s.occupied = 1;
							}else{
								s.occupied = -1;
							}
							player1Turn ^= true;
						}else{
							AudioInputStream denySound;
							Clip denyClip;
							try {
								denySound = AudioSystem.getAudioInputStream(this.getClass().getResource("/snd/deny.wav"));
								denyClip = AudioSystem.getClip();
								denyClip.open(denySound);
								denyClip.start();
							} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
								e.printStackTrace();
							}
						}
						//Tie Game
						gameOver = true;
						for(int i = 0; i<9; i++){
							if(spaces.get(i).occupied==0){
								gameOver = false;
							}
						}
						//Vertical
						for(int i = 0; i < 3; i++){
							int sum = 0;
							sum += spaces.get((i*3)).occupied;
							sum += spaces.get((i*3)+1).occupied;
							sum += spaces.get((i*3)+2).occupied;
							if(sum == 3){
								gameOver = true;
								winner = 1;
								p1Wins++;
							}else if(sum == -3){
								gameOver = true;
								winner = 2;
								p2Wins++;
							}
						}
						//Horizontal
						for(int i = 0; i < 3; i++){
							int sum = 0;
							sum += spaces.get(i).occupied;
							sum += spaces.get(i+3).occupied;
							sum += spaces.get(i+6).occupied;
							if(sum == 3){
								gameOver = true;
								winner = 1;
								p1Wins++;
							}else if(sum == -3){
								gameOver = true;
								winner = 2;
								p2Wins++;
							}
						}
						//Diagonal
						//Top to bottom
						int sum = 0;
						sum += spaces.get(0).occupied;
						sum += spaces.get(4).occupied;
						sum += spaces.get(8).occupied;
						if(sum == 3){
							gameOver = true;
							winner = 1;
							p1Wins++;
						}else if(sum == -3){
							gameOver = true;
							winner = 2;
							p2Wins++;
						}
						//Bottom to top
						sum = 0;
						sum += spaces.get(2).occupied;
						sum += spaces.get(4).occupied;
						sum += spaces.get(6).occupied;
						if(sum == 3){
							gameOver = true;
							winner = 1;
							p1Wins++;
						}else if(sum == -3){
							gameOver = true;
							winner = 2;
							p2Wins++;
						}
					}
				}
			}
			if(resetButton.isClicked(gc)){
				AudioInputStream resetSound;
				Clip resetClip;
				try {
					resetSound = AudioSystem.getAudioInputStream(this.getClass().getResource("/snd/reset.wav"));
					resetClip = AudioSystem.getClip();
					resetClip.open(resetSound);
					resetClip.start();
				} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
					e.printStackTrace();
				}
				player1Turn = true;
				gameOver = false;
				winner = 0;
				for(Space s: spaces){
					s.occupied = 0;
				}
			}
		}
	}
	
	void setup(){
		try {
			h1 = Font.createFont(Font.TRUETYPE_FONT, h1Stream).deriveFont(24f);
		} catch (FontFormatException | IOException e) {
			e.printStackTrace();
		}
		gc.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/img/icon.png")));
		gc.setBackgroundColor(bgColor);
		gc.clear();
		gc.setAntiAlias(true);
		for(int i = 0; i<9; i++){
			Space s = new Space();
			s.placeX = (i/3);
			s.placeY = (i%3);
			s.setBounds(115+(gridSize*s.placeX), 115+(gridSize*s.placeY), gridSize, gridSize);
			spaces.add(s);
		}
		gc.enableMouse();
		gc.enableMouseMotion();
		gameOver = false;
	}
	
	void draw(){
		m.x = gc.getMouseX();
		m.y	= gc.getMouseY();
		synchronized(gc){
			gc.clear();
			gc.setStroke(5);
			gc.setColor(carve);
			gc.fillRoundRect(25,25,750,60,25,25);
			gc.fillRoundRect(100, 100, boardSize, boardSize+10,25,25);
			gc.setColor(wood);
			gc.fillRoundRect(25,25,750,50,25,25);
			gc.fillRoundRect(100, 100, boardSize, boardSize,25,25);
			gc.setColor(carve);
			for(Space s: spaces){
				gc.drawRoundRect(115+(gridSize*s.placeX), 115+(gridSize*s.placeY), gridSize, gridSize,5,5);
				switch(s.occupied){
				case -1:
					gc.drawOval(s.x+15, s.y+15, s.width-30, s.width-30);
					break;
				case 0:
					break;
				case 1:
					gc.drawLine(s.x+15, s.y+15, (int)s.getMaxX()-15, (int)s.getMaxY()-15);
					gc.drawLine( s.x+15, (int)s.getMaxY()-15, (int)s.getMaxX()-15, s.y+15);
					break;
				}
			}
			if(!gameOver){
				gc.setStroke(10);
				if(player1Turn){
					for(Space s: spaces){
						if(s.contains(m)){
							if(s.occupied == 0){
								gc.setColor(Color.GREEN);
								gc.drawLine(s.x+15, s.y+15, (int)s.getMaxX()-15, (int)s.getMaxY()-15);
								gc.drawLine( s.x+15, (int)s.getMaxY()-15, (int)s.getMaxX()-15, s.y+15);
							}else{
								gc.setColor(Color.RED);
								gc.drawLine(s.x+15, s.y+15, (int)s.getMaxX()-15, (int)s.getMaxY()-15);
								gc.drawLine( s.x+15, (int)s.getMaxY()-15, (int)s.getMaxX()-15, s.y+15);
							}
						}
					}
				}else{
					for(Space s: spaces){
						if(s.contains(m)){
							if(s.occupied == 0){
								gc.setColor(Color.GREEN);
								gc.drawOval(s.x+15, s.y+15, s.width-30, s.width-30);
							}else{
								gc.setColor(Color.RED);
								gc.drawOval(s.x+15, s.y+15, s.width-30, s.width-30);
							}
						}
					}
				}
				gc.setFont(h1);
				resetButton.draw(h1, gc, "Reset", carve, wood, 400, 30, 5, true, true);
				gc.setColor(carve);
				if(player1Turn){
					gc.drawString("Player 1's Turn (X)", 30, 60);
				}else{
					gc.drawString("Player 2's Turn (O)", 30, 60);
				}
				gc.fillRoundRect(485, 30, 100, 40, 5, 5);
				gc.setColor(wood);
				gc.drawString(p1Wins + " : " + p2Wins, 500, 60);
			}else{
				gc.setColor(shadow);
				gc.fillRect(0, 0, vs, vs);
				gc.setStroke(gridSize);
				gc.setColor(highlight);
				//Vertical
				for(int i = 0; i < 3; i++){
					int sum = 0;
					sum += spaces.get((i*3)).occupied;
					sum += spaces.get((i*3)+1).occupied;
					sum += spaces.get((i*3)+2).occupied;
					if(Math.abs(sum) == 3){
						gc.drawLine((int)spaces.get((i*3)).getCenterX(), (int)spaces.get((i*3)).getCenterY(), (int)spaces.get((i*3)+2).getCenterX(), (int)spaces.get((i*3)+2).getCenterY());
					}
				}
				//Horizontal
				for(int i = 0; i < 3; i++){
					int sum = 0;
					sum += spaces.get(i).occupied;
					sum += spaces.get(i+3).occupied;
					sum += spaces.get(i+6).occupied;
					if(Math.abs(sum) == 3){
						gc.drawLine((int)spaces.get(i).getCenterX(), (int)spaces.get(i).getCenterY(), (int)spaces.get(i+6).getCenterX(), (int)spaces.get(i+6).getCenterY());
					}
				}
				//Diagonal
				//Top to bottom
				int sum = 0;
				sum += spaces.get(0).occupied;
				sum += spaces.get(4).occupied;
				sum += spaces.get(8).occupied;
				if(Math.abs(sum) == 3){
					gc.drawLine((int)spaces.get(0).getCenterX(), (int)spaces.get(0).getCenterY(), (int)spaces.get(8).getCenterX(), (int)spaces.get(8).getCenterY());
				}
				//Bottom to top
				sum = 0;
				sum += spaces.get(2).occupied;
				sum += spaces.get(4).occupied;
				sum += spaces.get(6).occupied;
				if(Math.abs(sum) == 3){
					gc.drawLine((int)spaces.get(2).getCenterX(), (int)spaces.get(2).getCenterY(), (int)spaces.get(6).getCenterX(), (int)spaces.get(6).getCenterY());
				}
				gc.setStroke(5);
				gc.setColor(carve);
				gc.fillRoundRect(25,((vs/2)-50),750,110,5,5);
				gc.setColor(wood);
				gc.fillRoundRect(25,((vs/2)-50),750,100,5,5);
				gc.setColor(carve);
				if(winner!=0){
					gc.drawString("Game over, player " + winner + " wins.", 45, ((vs/2)-15));
				}else{
					gc.drawString("Game over, game tied.", 45, ((vs/2)-15));
				}
				gc.setFont(h1);
				resetButton.draw(h1, gc, "Reset", carve, wood, 500, ((vs/2)-15), 5, true, true);
				gc.setColor(carve);
			}
		}
		gc.sleep(1);
	}
}
