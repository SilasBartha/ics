package scripts;

import java.awt.Rectangle;

public class Space extends Rectangle{
	private static final long serialVersionUID = 1L;
	//Location on grid
	int placeX = 0, placeY = 0;
	//Occupied State
	int occupied = 0;
	//Constructor
	Space(){
	}

}
